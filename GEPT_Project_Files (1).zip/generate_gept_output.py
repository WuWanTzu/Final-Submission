import openai

# Replace with your actual OpenAI API key
openai.api_key = "your-api-key"

prompt = """
Imagine you are a GEPT high-intermediate speaking test examiner. Conduct Part 1 of the speaking test by asking two realistic questions. After the test taker replies, give feedback correcting grammar and fluency. Then ask one follow-up question. Provide the entire dialogue.
"""

response = openai.ChatCompletion.create(
    model="gpt-4",
    messages=[
        {"role": "system", "content": "You are a helpful English speaking test examiner."},
        {"role": "user", "content": prompt}
    ]
)

output = response['choices'][0]['message']['content']

with open("gept_output.txt", "w") as f:
    f.write(output)

print("AI output saved to gept_output.txt")
